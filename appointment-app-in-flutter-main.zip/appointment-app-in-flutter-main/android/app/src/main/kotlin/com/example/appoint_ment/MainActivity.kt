package com.example.appoint_ment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
